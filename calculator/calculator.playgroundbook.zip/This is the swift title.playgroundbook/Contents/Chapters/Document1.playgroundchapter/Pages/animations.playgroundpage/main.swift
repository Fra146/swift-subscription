//#-hidden-code
//
//  main.swift
//
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//
//#-code-completion(everything, hide)
//#-code-completion(keyword, show, for, func, if, let, var, while, in)
//#-code-completion(literal, show, literal, array, boolean, color, dictionary, image, string, integer, nil)
//#-code-completion(snippet, show, repeat, switch, protocol, enum, struct, class, return)
//#-code-completion(currentmodule, show)
//#-code-completion(module, show, MyFiles, SpriteKit, Swift, UIKit)
//#-code-completion(identifier, show, (hue:saturation:brightness:alpha:), (image:), (image:columns:rows:), (image:columns:rows:isDynamic:name:), (image:name:), (red:green:blue:alpha:), (text:color:), (text:color:font:size:name:), (type:), (type:text:name:), (width:height:), (x:y:), AcademyEngravedLET, AmericanTypewriter, AppleSDGothicNeo, Arial, ArialRoundedMTBold, Avenir, AvenirNext, AvenirNextCondensed, Baskerville, Bodoni72, Bounce1, Bounce2, Bounce3, BradleyHand, Button, ButtonType, ChalkDuster, ChalkboardSE, Cochin, Color, Copperplate, Courier, CourierNew, Didot, Font, Futura, Georgia, GillSans, Graphic, Helvetica, HelveticaNeue, HiraginoMinchoProN, HiraginoSans, Impact, Joint, Label, MarkerFelt, Menlo, Noteworthy, Optima, Palatino, Papyrus, PartyLET, PingFangSC, PingFangTC, Point, SavoyeLET, Scene, Size, SnellRoundhand, Sprite, String, Superclarendon, SystemBoldItalic, SystemFontBlack, SystemFontBold, SystemFontHeavy, SystemFontLight, SystemFontMedium, SystemFontRegular, SystemFontSemibold, SystemFontThin, SystemFontUltraLight, SystemHeavyItalic, SystemItalic, Thonburi, TimesNewRoman, Touch, TrebuchetMS, Verdana, Zapfino, add(joint:), allowsRotation, allowsTouchInteraction, alpha, angle, angularDamping, angularVelocity, applyForce(x:y:duration:), applyImpulse(x:y:), arabic, area, aspectFitMaximum, aspectFitMinimum, audioPlayAction(fileNamed:), backgroundColor, backgroundColors, backgroundImage, beam, beep, blip, boing1, boing2, boing3, boop1, boop2, boop3, bottom, bounciness, buttonPress1, buttonType, capturesTouches, center, chinese, chineseHongKong, chineseTaiwan, circle(radius:color:), circle(radius:color:colors:), circlePoints(radius:count:), clang, clear(), clunk, collisionNotificationCategories, constrained, containing:, contentPresentation, crash, crystal, customShape(path:color:), customShape(path:color:colors:), czech, danish, defeat1, density, distance(from:), drag, drop, dutch, echobird, electricBeep1, electricBeep2, electricBeep3, electricBeep4, electricBeepFader, englishAustralia, englishIreland, englishSouthAfrica, englishUK, englishUS, explosionShort, fadeAlpha(by:duration:), fadeAlpha(to:duration:), fadeIn(after:), fadeOut(after:), finnish, firstTouch, fit(within:), fixed(from:to:at:), font, fontSize, force, frenchCanada, frenchFrance, friction, friendlyPassage, german, getGraphics(at:in:), getGraphics(named:), getGraphicsWithName(containing:), graphics, greek, green, gridPoints(size:count:angle:), hasCollisionBorder, hebrew, height, helicopterWhoosh, hindi, horizontalGravity, hue:saturation:brightness:alpha:, hungarian, image, image(text:), image:, image:columns:rows:, image:columns:rows:isDynamic:name:, image:name:, indonesian, interactionCategory, isAffectedByGravity, isDynamic, isGridVisible, isResting, italian, japanese, joints, korean, laser1, laser2, laser3, left, limit(from:at:to:at:), line(length:thickness:color:), line(length:thickness:color:colors:), line(start:end:thickness:color:), line(start:end:thickness:color:colors:), linearDamping, location, machineGreeting1, machineGreeting2, machineGreeting3, mass, miss, move(to:duration:), moveBy(x:y:duration:), name, node, norwegian, onCollisionHandler, onGraphicTouchedHandler, onTouchMovedHandler, orbit(x:y:period:), orbitAction(x:y:period:), overlaid(with:offsetBy:), physicsBody, pi, pin(from:to:around:), pinned, place(_:), place(_:at:), place(_:at:anchoredTo:), place(at:), playSound(_:volume:), pleasantDing1, pleasantDing2, pleasantDing3, polish, polygon(radius:sides:color:), polygon(radius:sides:color:colors:), pop, pop1, pop2, portugueseBrazil, portuguesePortugal, position, powerUp1, powerUp2, powerUp3, powerUp4, powerup, pulsate(), pulsate(period:count:), puzzleJam, radiant, randomCharacter, randomIndex, randomItem, rectangle(width:height:cornerRadius:color:), rectangle(width:height:cornerRadius:color:colors:), red, red:green:blue:alpha:, remove(), remove(_:), remove(joint:), removeAction(forKey:), removeAllActions(), removeGraphics(named:), removeHandler(forInteraction:), removeJoints(named:), restituion, retroBass, retroCollide1, retroCollide2, retroCollide3, retroCollide4, retroCollide5, retroJump1, retroJump2, retroPowerUp1, retroPowerUp2, retroTwang1, retroTwang2, right, romanian, rotate(byAngle:duration:), rotate(toAngle:duration:), rotation, rotationalDrag, run(_:), run(_:key:), runAnimation(_:timePerFrame:numberOfTimes:), russian, scale, scale(by:duration:), scale(to:duration:), scaleX(by:y:duration:), scaleX(to:y:duration:), scaledImage(size:), setHandler(for:handler:), setOnCollisionHandler(_:), setOnTouchHandler(_:), setOnTouchMovedHandler(_:), setTintColor(_:blend:), setVelocity(x:y:), shake(duration:), shuffle(), shuffled(), size, sliding(from:to:at:axis:), slovak, somethingBad1, somethingBad2, somethingBad3, somethingBad4, somethingGood1, somethingGood2, somethingGood3, somethingGood4, somethingGood5, somethingGood6, somethingGood7, sonar, spanishMexico, spanishSpain, speak(text:), speak(text:withAccent:rate:pitch:completion:), spin(period:), splat, spring(from:at:to:at:), spring1, spring2, spring3, spring4, spriteA, spriteB, squarePoints(width:count:), squeak, star(radius:points:sharpness:color:), star(radius:points:sharpness:color:colors:), strangeWobble, strokeColor, strokeWidth, swedish, text, text:, text:color:, text:color:font:size:name:, textColor, thai, thud, tick, top, touch, touchCancelled, touchHandler, touchUp, tubeHit1, tubeHit2, tubeHit3, turkish, type:, type:text:name:, velocity, verticalGravity, victory1, victory2, victory3, victory4, wall, warble, warp, width, width:height:, x, x:y:, x:y:duration:, xScale, y, yScale, zap)
//#-code-completion(description, hide, "(hue: CGFloat, saturation: CGFloat, brightness: CGFloat, alpha: CGFloat)", "(x: CGFloat, y: CGFloat)", "(x: Float, y: Float)", "(width: CGFloat, height: CGFloat)", "(width: Float, height: Float)", "(point: CGPoint)", "(from: Decoder) throws", "(music: Music, volume: Int)", "playMusic(music: Music, volume: Int)", "(sound: Sound, volume: Int)", "playSound(sound: Sound, volume: Int)", "from(playgroundValue: PlaygroundValue)", "(sound: Sound)", "(sound: Sound, loopFireHandler: (() -> Void)?)")
//#-end-hidden-code
import SpriteKit

setUpLiveView()

// /*#-localizable-zone(shapes1)*/Creates a circle sprite./*#-end-localizable-zone*/
let circle = Graphic.circle(radius: 75, color: Color.random())
scene.place(circle, at: Point(x: 200, y: 0))

// /*#-localizable-zone(shapes2)*/Creates a polygon sprite./*#-end-localizable-zone*/
let polygon = Graphic.polygon(radius: 75, sides: 7, color: Color.random())
scene.place(polygon, at: Point(x: -200, y: 0))

// /*#-localizable-zone(shapes3)*/Makes the circle draggable./*#-end-localizable-zone*/
circle.isDraggable = true

// /*#-localizable-zone(shapes4)*/Creates an animation on touch down./*#-end-localizable-zone*/
circle.setHandler(for: .touch) { _ in
    circle.backgroundColor = circle.backgroundColor.darker()
    circle.scale(to: 1.1, duration: 0.2)
    circle.backgroundColor = Color.random()
}

// /*#-localizable-zone(shapes5)*/Returns the circle to normal scale on touch up./*#-end-localizable-zone*/
circle.setHandler(for: .touchUp) { _ in
    circle.backgroundColor = Color.random()
    circle.scale(to: 1, duration: 0.2)
}

// /*#-localizable-zone(shapes6)*/Creates an SKAction sequence to animate the polygon./*#-end-localizable-zone*/
let rotateAction = SKAction.rotate(byAngle: 3.3, duration: 0.3)
let snapBack = SKAction.rotate(byAngle: -0.25, duration: 0.2)
let sequence = SKAction.sequence([rotateAction, snapBack])

// /*#-localizable-zone(shapes7)*/Runs the animation sequence when the user taps the polygon./*#-end-localizable-zone*/
polygon.setHandler(for: .touch) { _ in
    polygon.run(sequence)
}
